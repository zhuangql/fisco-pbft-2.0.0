.. spelling::

    rang

.. index::
  single: unsorted ; rang

.. _pkg.rang:

rang
====

- https://agauniyal.github.io/rang/
- `Official GitHub <https://github.com/agauniyal/rang>`__
- `Hunterized <https://github.com/hunter-packages/rang>`__
- `Example <https://github.com/ruslo/hunter/blob/master/examples/rang/CMakeLists.txt>`__

.. literalinclude:: /../examples/rang/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
