.. spelling::

    wiki

All packages
------------

.. toctree::
   :maxdepth: 1
   :glob:

   pkg/*
