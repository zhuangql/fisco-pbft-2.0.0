.. spelling::

    gst

.. index:: media ; gst_plugins_ugly

.. _pkg.gst_plugins_ugly:

gst_plugins_ugly
================

-  `Official <https://gstreamer.freedesktop.org>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/gst_plugins_ugly/CMakeLists.txt>`__

.. code-block:: cmake

    hunter_add_package(gst_plugins_ugly)
    # ???
