#if __ANDROID_API__ < 21
#undef HAVE_STRUCT_DIRENT64
#endif
