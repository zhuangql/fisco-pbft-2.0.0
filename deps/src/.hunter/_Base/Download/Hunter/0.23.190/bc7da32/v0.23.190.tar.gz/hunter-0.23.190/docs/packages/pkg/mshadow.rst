.. spelling::

    mshadow

.. index::
  single: unsorted ; mshadow

.. _pkg.mshadow:

mshadow
=======

-  `Official GitHub <https://github.com/dmlc/mshadow>`__
-  `Hunterized <https://github.com/hunter-packages/mshadow>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/mshadow/CMakeLists.txt>`__

.. literalinclude:: /../examples/mshadow/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
