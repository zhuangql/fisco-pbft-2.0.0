.. spelling::

    date

.. index::
  single: unsorted ; date

.. _pkg.date:

date
====

- https://github.com/HowardHinnant/date
- `Example <https://github.com/ruslo/hunter/blob/master/examples/date/CMakeLists.txt>`__

.. literalinclude:: /../examples/date/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
