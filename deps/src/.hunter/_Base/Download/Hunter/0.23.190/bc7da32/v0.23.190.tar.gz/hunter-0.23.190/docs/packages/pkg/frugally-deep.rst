.. spelling::

    frugally-deep

.. index:: machine-learning ; frugally-deep

.. _pkg.frugally-deep:

frugally-deep
=============

-  `Official <https://github.com/Dobiasd/frugally-deep>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/frugally-deep/CMakeLists.txt>`__

.. literalinclude:: /../examples/frugally-deep/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
