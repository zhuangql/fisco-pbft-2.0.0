.. spelling::

    certifi

.. index::
  single: python ; pip_certifi

.. _pkg.pip_certifi:

pip_certifi
===========

- `PyPI <https://pypi.org/project/certifi>`__
- `Example <https://github.com/ruslo/hunter/blob/master/examples/pip_certifi/CMakeLists.txt>`__

.. literalinclude:: /../examples/pip_certifi/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
