.. spelling::

    pcre2
    pcre

.. index::
  single: unsorted ; pcre2

.. _pkg.pcre2:

pcre2
=====

- https://www.pcre.org/
- `Hunterized <https://github.com/hunter-packages/pcre2>`__
- `Example <https://github.com/ruslo/hunter/blob/master/examples/pcre2/CMakeLists.txt>`__

.. literalinclude:: /../examples/pcre2/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
